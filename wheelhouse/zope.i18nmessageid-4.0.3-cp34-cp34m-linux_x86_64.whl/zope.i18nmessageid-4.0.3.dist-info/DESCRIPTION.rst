To translate any text, we must be able to discover the source domain
of the text.  A source domain is an identifier that identifies a
project that produces program source strings.  Source strings occur as
literals in python programs, text in templates, and some text in XML
data.  The project implies a source language and an application
context.

We can think of a source domain as a collection of messages and
associated translation strings.

We often need to create unicode strings that will be displayed by
separate views.  The view cannot translate the string without knowing
its source domain.  A string or unicode literal carries no domain
information, therefore we use messages.  Messages are unicode strings
which carry a translation source domain and possibly a default
translation.  They are created by a message factory. The message
factory is created by calling ``MessageFactory`` with the source
domain.

This package provides facilities for *declaring* such messages within
program source text;  translation of the messages is the responsiblitiy
of the 'zope.i18n' package.

Please see http://docs.zope.org/zope.i18nmessageid/ for the documentation.


=======
CHANGES
=======


4.0.3 (2014-03-19)
------------------

- Added support for Python 3.4.

- Updated ``boostrap.py`` to version 2.2.


4.0.2 (2012-12-31)
------------------

- Fleshed out PyPI Trove classifiers.

4.0.1 (2012-11-21)
------------------

- Added support for Python 3.3.

4.0.0 (2012-05-16)
------------------

- Automated build of Sphinx HTML docs and running doctest snippets via tox.

- Removed use of '2to3' and associated fixers when installing under Py3k.
  The code is now in a "compatible subset" which supports Python 2.6, 2.7,
  and 3.2, including PyPy 1.8 (the version compatible with the 2.7 language
  spec).

- 100% unit test coverage.

- Move doctest examples into Sphinx documentation.

- Dropped explicit support for Python 2.4 / 2.5 / 3.1.

- Added explicit support for PyPy.

- Added 'setup.py dev' alias (runs ``setup.py develop`` plus installs
  ``nose`` and ``coverage``).

- Added 'setup.py docs' alias (installs ``Sphinx`` and dependencies).


3.6.1 (2011-07-20)
------------------

- Correct metadata in this file for release date.

3.6.0 (2011-07-20)
------------------

- Python 3 support.

- Don't attempt to compile C extensions on PyPy or Jython.

- Add a tox.ini (see http://tox.readthedocs.org/en/latest/) for easier
  automated testing.

3.5.3 (2010-08-10)
------------------

- Made compilation of C extension optional again; 3.5.1 broke this
  inasmuch as this package become unusable on non-CPython platforms.
  Making the compilation of the C extension optional again implied
  removing ``setup.py`` code added in 3.5.1 which made the C extension
  a setuptools "Feature" and readding code from 3.5.0 which overrides
  the distutils ``build_ext`` command.

- Move pickle equality tests into a unittest.TestCase test to make it
  easier to condition the tests on whether the C extension has been
  compiled.  This also makes the tests pass on Jython.

3.5.2 (2010-04-30)
------------------

- Removed use of 'zope.testing.doctestunit' in favor of stdlib's 'doctest.

3.5.1 (2010-04-10)
------------------

- LP #257657 / 489529:  Fix memory leak in C extension.

- Fixed the compilation of the C extension with python 2.6: refactored it as a
  setuptools Feature.

3.5.0 (2009-06-27)
------------------

- Made compilation of C extension optional.

- Added support to bootstrap on Jython.

- Changed package's mailing list address from zope3-dev at zope.org to
  zope-dev at zope.org, because zope3-dev is now retired.

- Reformatted change log to common formatting style.

- Update package description and docs a little.

- Remove old .cfg files for zpkg.

3.4.3 (2007-09-26)
------------------

- Make PyPI the home URL.

3.4.2 (2007-09-25)
------------------

- Moved the ``ZopeMessageFactory`` from ``zope.app.i18n`` to this package.

3.4.0 (2007-07-19)
------------------

- Remove incorrect dependency.

- Create final release to reflect package status.

3.2.0 (2006-01-05)
------------------

- Corresponds to the verison of the zope.i18nmessageid package shipped as
  part of the Zope 3.2.0 release.

- Implemented 'zope.i18nmessageid.message' as a C extension.

- Deprecated 'zope.i18nmessageid.messageid' APIs ('MessageID',
  'MessageIDFactory') in favor of replacements in 'zope.i18nmessageid.message'
  ('Message', 'MessageFactory').  Deprecated items are scheduled for removal
  in Zope 3.3.

3.0.0 (2004-11-07)
------------------

- Corresponds to the verison of the zope.i18nmessageid package shipped as
  part of the Zope X3.0.0 release.


