
import persistent

class TestObject(persistent.Persistent):
    pass
